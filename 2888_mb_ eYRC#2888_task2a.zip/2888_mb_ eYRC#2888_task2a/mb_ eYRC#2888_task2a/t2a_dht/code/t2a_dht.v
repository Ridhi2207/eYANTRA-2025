
module t2a_dht(
    input clk_50M,
    input reset,
    inout sensor,
    output reg [7:0] T_integral,
    output reg [7:0] RH_integral,
    output reg [7:0] T_decimal,
    output reg [7:0] RH_decimal,
    output reg [7:0] Checksum,
    output reg data_valid
);

    initial begin
        T_integral = 0;
        RH_integral = 0;
        T_decimal = 0;
        RH_decimal = 0;
        Checksum = 0;
        data_valid = 0;
    end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

    assign sensor = 1'bz;

    reg sensor_sync1, sensor_sync2;
    wire sensor_in_raw = sensor;

    always @(posedge clk_50M or negedge reset) begin
        if (!reset) begin
            sensor_sync1 <= 1'b1;
            sensor_sync2 <= 1'b1;
        end else begin
            sensor_sync1 <= sensor_in_raw;
            sensor_sync2 <= sensor_sync1;
        end
    end
    wire sensor_in = sensor_sync2;

    // Response pulses (~80 us) ±10%
    localparam RESP_MIN     = 3600;  // 72 us
    localparam RESP_MAX     = 4400;  // 88 us
    localparam RESP_TIMEOUT = 6000;  // ~120 us guard

    // Bit preamble LOW ~50 us ±10%
    localparam PRE_MIN      = 2200;  // 44 us
    localparam PRE_MAX      = 2800;  // 56 us
    localparam BIT_TIMEOUT  = 6000;  // ~120 us guard

    // Bit-HIGH decision threshold (0≈26us ~1300, 1≈70us ~3500)
    localparam HIGH_THRESH  = 2400;  // ~48 us midpoint

    localparam [3:0]
        IDLE        = 4'd0,
        RESP_L_MEAS = 4'd1,
        RESP_H_MEAS = 4'd2,
        BIT_WAIT_L  = 4'd3,
        BIT_L_MEAS  = 4'd4,
        BIT_H_MEAS  = 4'd5,
        VALIDATE    = 4'd6;

    reg [3:0]  state;
    reg [20:0] timer;          // generic timer
    reg [5:0]  bit_cnt;        // 0..40
    reg [39:0] data_reg;       // RH_int, RH_dec, T_int, T_dec, checksum (MSB-first)

    always @(posedge clk_50M or negedge reset) begin
        if (!reset) begin
            state       <= IDLE;
            timer       <= 21'd0;
            bit_cnt     <= 6'd0;
            data_reg    <= 40'd0;

            T_integral  <= 8'd0;
            T_decimal   <= 8'd0;
            RH_integral <= 8'd0;
            RH_decimal  <= 8'd0;
            Checksum    <= 8'd0;
            data_valid  <= 1'b0;
        end else begin
            data_valid <= 1'b0; // one-cycle pulse default

            case (state)
        
            IDLE: begin
                timer   <= 21'd0;
                bit_cnt <= 6'd0;
               
                if (sensor_in == 1'b0) begin
                    timer <= 21'd0;
                    state <= RESP_L_MEAS;
                end
            end

            // Measure response LOW (~80 us) : count while LOW, stop when HIGH
            RESP_L_MEAS: begin
                if (sensor_in == 1'b0) begin
                    if (timer >= RESP_TIMEOUT) begin
                        state <= IDLE; timer <= 21'd0;
                    end else begin
                        timer <= timer + 1'b1;
                    end
                end else begin
                    // went HIGH: check width
                    if (timer >= RESP_MIN && timer <= RESP_MAX) begin
                        timer <= 21'd0;
                        state <= RESP_H_MEAS;
                    end else begin
                        state <= IDLE; timer <= 21'd0;
                    end
                end
            end

            // Measure response HIGH (~80 us) : count while HIGH, stop when LOW
            RESP_H_MEAS: begin
                if (sensor_in == 1'b1) begin
                    if (timer >= RESP_TIMEOUT) begin
                        state <= IDLE; timer <= 21'd0;
                    end else begin
                        timer <= timer + 1'b1;
                    end
                end else begin
                    // went LOW: check width then proceed to bits
                    if (timer >= RESP_MIN && timer <= RESP_MAX) begin
                        timer    <= 21'd0;
                        bit_cnt  <= 6'd0;
                        data_reg <= 40'd0;
                        state    <= BIT_WAIT_L;
                    end else begin
                        state <= IDLE; timer <= 21'd0;
                    end
                end
            end

            // Wait for bit's LOW preamble (LEVEL: wait until LOW)
            BIT_WAIT_L: begin
                if (sensor_in == 1'b0) begin
                    timer <= 21'd0;
                    state <= BIT_L_MEAS;
                end else begin
                    if (timer >= BIT_TIMEOUT) begin
                        state <= IDLE; timer <= 21'd0;
                    end else begin
                        timer <= timer + 1'b1;
                    end
                end
            end

            // Measure LOW preamble (~50 us) : count while LOW, stop on HIGH
            BIT_L_MEAS: begin
                if (sensor_in == 1'b0) begin
                    if (timer >= BIT_TIMEOUT) begin
                        state <= IDLE; timer <= 21'd0;
                    end else begin
                        timer <= timer + 1'b1;
                    end
                end else begin
                    // went HIGH: preamble width check
                    if (timer >= PRE_MIN && timer <= PRE_MAX) begin
                        timer <= 21'd0;
                        state <= BIT_H_MEAS;
                    end else begin
                        state <= IDLE; timer <= 21'd0;
                    end
                end
            end

            // Measure HIGH width and decide bit at return to LOW
            BIT_H_MEAS: begin
                if (sensor_in == 1'b1) begin
                    if (timer >= BIT_TIMEOUT) begin
                        state <= IDLE; timer <= 21'd0;
                    end else begin
                        timer <= timer + 1'b1;
                    end
                end else begin
                    // back to LOW -> decide bit
                    if (timer > HIGH_THRESH)
                        data_reg <= {data_reg[38:0], 1'b1};
                    else
                        data_reg <= {data_reg[38:0], 1'b0};

                    bit_cnt <= bit_cnt + 6'd1;
                    timer   <= 21'd0;

                    if (bit_cnt == 6'd39)
                        state <= VALIDATE;
                    else
                        state <= BIT_WAIT_L;
                end
            end

     
            VALIDATE: begin
                // 8-bit sum (mod 256)
                // Do it in 8-bit steps to ensure wrap:
                // s1 = a + b; s2 = s1 + c; s3 = s2 + d;
              
               
                if ( ((data_reg[39:32] + data_reg[31:24] +
                       data_reg[23:16] + data_reg[15:8]) & 8'hFF)
                     == data_reg[7:0] ) begin
                    RH_integral <= data_reg[39:32];
                    RH_decimal  <= data_reg[31:24];
                    T_integral  <= data_reg[23:16];
                    T_decimal   <= data_reg[15:8];
                    Checksum    <= data_reg[7:0];
                    data_valid  <= 1'b1; // one clock
                end
                state <= IDLE;
                timer <= 21'd0;
            end

            default: begin
                state <= IDLE;
                timer <= 21'd0;
            end
            endcase
        end
    end

//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////
  
endmodule
